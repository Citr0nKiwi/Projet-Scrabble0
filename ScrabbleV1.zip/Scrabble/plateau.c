#include "plateau.h"


//Programme qui initialise le plateau
void initPlateau(Case plateau[TAILLE_PLATEAU][TAILLE_PLATEAU]) {
    int i,j;
    Case laCase;

    for (i = 0; i < TAILLE_PLATEAU; i++) {
        for (j = 0; j < TAILLE_PLATEAU; j++) {
            laCase.legende = ' ';
            laCase.caractere = ' ';
            plateau[i][j] = laCase;
        }

    }
}

void creationPlateau(Case plateau[TAILLE_PLATEAU][TAILLE_PLATEAU]) {
Case laCase;
int a = 2;
int i;

    //Init du plateau
    initPlateau(plateau);

    //Affichage de la lettre pr�c�dent la colonne : A B C ....O
    laCase.legende = 'A';
    laCase.caractere = ' ';
    for (i = 1; i < TAILLE_PLATEAU; i++) {
        plateau[0][i] = laCase;
        laCase.legende = laCase.legende + 1;
        laCase.caractere = ' ';
    }

    //Affichage du nombre pr�cedent la ligne : 1 2 3 ...9
    laCase.legende = '1';
    laCase.caractere = ' ';
    for (i = 1; i < 11; i++) {
        plateau[i][0] = laCase;
        laCase.legende = laCase.legende + 1;
        laCase.caractere = ' ';
    }

    //Affichage du nombre pr�cedent la ligne : 10 11 12...15
    laCase.legende = '1';
    laCase.caractere = '0';
    for (i = 10; i < TAILLE_PLATEAU; i++) {
        plateau[i][0] = laCase;
        laCase.legende = laCase.legende;
        laCase.caractere = laCase.caractere + 1;
    }

    //diagonale de '@'
    laCase.legende = '@';
    laCase.caractere = ' ';
    for (i = 2; i < TAILLE_PLATEAU; i++) {
        plateau[i][a] = laCase;
        a++;
    }
    a = 2;

    //diagonale de '@'
    laCase.legende = '@';
    laCase.caractere = ' ';
    for (i = TAILLE_PLATEAU - 2; i >= 2; i--) {
        plateau[i][a] = laCase;
        a++;
    }


laCase.legende = '�';
laCase.caractere = ' ';
plateau[1][1] = laCase;
plateau[8][1] = laCase;
plateau[15][1] = laCase;
plateau[1][8] = laCase;
plateau[15][8] = laCase;
plateau[1][15]=laCase;
plateau[8][15]=laCase;
plateau[15][15]=laCase;

laCase.legende = '&';
laCase.caractere = ' ';
plateau[1][4]=laCase;
plateau[1][12]=laCase;
plateau[3][7]=laCase;
plateau[3][9]=laCase;
plateau[4][1]=laCase;
plateau[4][8]=laCase;
plateau[4][15]=laCase;
plateau[7][3]=laCase;
plateau[7][7]=laCase;
plateau[7][9]=laCase;
plateau[7][13]=laCase;
plateau[8][4]=laCase;

laCase.legende = '#';
laCase.caractere = ' ';
plateau[8][8]=laCase;


laCase.legende = '&';
laCase.caractere = ' ';
plateau[8][12]=laCase;
plateau[9][3]=laCase;
plateau[9][7]=laCase;
plateau[9][9]=laCase;
plateau[9][13]=laCase;
plateau[12][1]=laCase;
plateau[12][8]=laCase;
plateau[12][15]=laCase;
plateau[13][7]=laCase;
plateau[13][9]=laCase;
plateau[15][4]=laCase;
plateau[15][12]=laCase;


laCase.legende = '%';
laCase.caractere = ' ';
plateau[2][6]=laCase;
plateau[2][10]=laCase;
plateau[6][2]=laCase;
plateau[6][6]=laCase;
plateau[6][10]=laCase;
plateau[6][14]=laCase;
plateau[10][2]=laCase;
plateau[10][6]=laCase;
plateau[10][10]=laCase;
plateau[10][14]=laCase;
plateau[14][6]=laCase;
plateau[14][10]=laCase;

}

// Fonction pour v�rifier si une lettre peut �tre plac�e � une position donn�e
int contactMotExistant(Case plateau[TAILLE_PLATEAU][TAILLE_PLATEAU], MotPlace motPlace) {
int i,j,k;
Case laCase;
int contact = 0;

i = (motPlace.ligne);
j = (int)(motPlace.colonne)-64;

for(k = 0; k < strlen(motPlace.mot);k++){//Parcours du mot place
        if(plateau[i][j].caractere == ' '){//si la case est vide on continue � parcourir le mot
                if(motPlace.sens == 'H')
                    j++;
                if(motPlace.sens == 'V')
                    i++;
        }
        else if (plateau[i][j].caractere != ' '){//la case n'est pas vide, il y a contact
            contact = 1;
        }
}
if (contact !=1){
    printf("Il faut placer le mot en contact avec un mot existant !!!\n");
    return(0);
}

// il y a contact, on place le mot
if (contact == 1){
    placeMot(plateau, motPlace);
}
return(1);
}



// Fonction pour placer un mot sur le palteau
void placeMot(Case plateau[TAILLE_PLATEAU][TAILLE_PLATEAU], MotPlace motPlace){
int i,j,k;
Case laCase;

i = (motPlace.ligne);
j = (int)(motPlace.colonne)-64;

    if(motPlace.sens == 'H'){
       for(k = 0; k < strlen(motPlace.mot);k++){
            laCase.legende = plateau[i][j].legende;
            laCase.caractere = motPlace.mot[k];
            plateau[i][j]=laCase;
            j++;
       }
    }
    else if(motPlace.sens == 'V'){
        for(k = 0; k < strlen(motPlace.mot);k++){
            laCase.legende = plateau[i][j].legende;
            laCase.caractere = motPlace.mot[k];
            plateau[i][j]=laCase;
            i++;
        }
    }
}
//Fonction pour le premier mot pos�
int placePremierMot(Case plateau[TAILLE_PLATEAU][TAILLE_PLATEAU], MotPlace motPlace){
int i,j,k;
Case laCase;
int place_OK = 0;

i = (motPlace.ligne);
j = (int)(motPlace.colonne)-64;

for(k = 0; k < strlen(motPlace.mot);k++){//Parcours du mot place
        if(plateau[i][j].legende != '#'){//si la case n'est pas sur # => Faux
                if(motPlace.sens == 'H')
                    j++;
                if(motPlace.sens == 'V')
                    i++;
        }
        else if (plateau[i][j].legende == '#'){
            place_OK = 1;
        }
}
if (place_OK !=1){
    printf("Il faut placer le premier mot sur #\n");
    return(0);
}


if (place_OK ==1){
    placeMot(plateau, motPlace);
}
return(1);
}

