#include "affichage.h"

//Programme qui affiche les informations des joueurs
void  afficherJoueur ( Joueur  joueur ){
    int i;

    printf ( "----Joueur%d----\n" , joueur.numeroJoueur );
    printf ( "|Pseudo : %s \n" , joueur.pseudo );
    if(joueur.masque == 0){
    for (i = 0; i < TAILLE_CHEVALET; i++) {
            printf("%c%d\t", joueur.chevalet[i].caractere, joueur.chevalet[i].valeur);
        }
    }
    printf ( "\n|Score : %d \n" , joueur.score );
    printf ( "----------------\n" );
}

//Programme qui affiche le plateau
void afficherPlateau(Case plateau[TAILLE_PLATEAU][TAILLE_PLATEAU]) {
    int i,j;

    for (i = 0; i < TAILLE_PLATEAU; i++) {
        for (j = 0; j < TAILLE_PLATEAU; j++) {
            if(plateau[i][j].legende == ' ')
                printf("| ");
            else
                printf("|%c", plateau[i][j].legende);
            if(plateau[i][j].caractere == ' ')
                printf(" ");
            else
                printf("%c", plateau[i][j].caractere);
        }
        printf("\n");
    }
}


//Programme qui affiche la pioche
void afficherPioche(Lettre pioche[]){
    int i;

    for( i = 0; i < NUM_LETTRE; i ++)
    {
        printf("%c %d ",pioche[i].caractere,pioche[i].valeur);
    }
    printf("\n");
}


//Programme qui affiche la partie information
void afficherPartieInfo(Joueur joueur) {
    int i;

    printf("----Joueur%d----\n",joueur.numeroJoueur);
    printf("|Pseudo : %s    \n",joueur.pseudo);
    printf("|Score : %d     \n",joueur.score);
    printf("----------------\n");

    if(joueur.masque == 0){
    for (i = 0; i < TAILLE_CHEVALET; i++) {
            printf("%c%d\t", joueur.chevalet[i].caractere, joueur.chevalet[i].valeur);
        }
    }
    printf("\n----------------\n");

}

//Programme qui affiche la partie interaction
void afficherPartieInter(MotPlace motPlace) {
    printf("----Mot a placer : %s----\n", motPlace.mot);
    printf("|Position a saisir :     \n");
    printf("|N Ligne : %d   N Colonne %c \n",motPlace.ligne, motPlace.colonne);
    printf("|Sens : %c   \n",motPlace.sens);
    printf("----------------\n");
}
