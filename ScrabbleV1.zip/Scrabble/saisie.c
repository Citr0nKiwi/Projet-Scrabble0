#include "saisie.h"

//Programme qui permet d'�viter les mauvaises saisies
void clsBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

//Pour que la saisie d'un entier soit blindee et soit uniquement un entier
int saisieInt(){

    int choix;
    int verifSaisie = 0;

        while (!verifSaisie) {
        printf("Votre choix : ");
        fflush(stdin);
        if (scanf("%d", &choix) == 1) {
            clsBuffer();
            verifSaisie = 1;
        } else {
            clsBuffer();
            printf("Saisissez uniquement un chiffre !\n\n");
        }
    }

    return choix;
}

//Pour que la saisie d'un entier soit blindee et soit uniquement un entier
char saisieChar(){

    char carac;
    int verifSaisie = 0;

        while (!verifSaisie) {
        printf("Votre choix : ");
        fflush(stdin);
        if (scanf("%c", &carac) == 1) {
            clsBuffer();
            verifSaisie = 1;
        } else {
            clsBuffer();
            printf("Saisissez uniquement un caractere !\n\n");
        }
    }

    return carac;

}

void saisieMot(char mot){

printf("Saisissez votre mot :\n");
fflush(stdin);
scanf("%s",&mot);
}

int saisieLigneMotPlace(){

    int ligne;
    do{
    printf("|N Ligne (Entre 0 et 15): ");
    //Blindage de saisie a des chiffres uniquements
    ligne = saisieInt();
    if((ligne < 0 || ligne > 15)){
        printf("Le nombre saisi n'est pas compris entre %d et %d !\n",0,15);
    }
    //Blindage de saisie entre le nombre maximum et le minimum �tabli
    }while(ligne < 0 || ligne > 15);

    return ligne;
}

char saisieColonneMotPlace(){

    char colonne;
    do{
    printf("|N Colonne (Entre A et O) : ");
    //Blindage de saisie a des chiffres uniquements
    colonne = toupper(saisieChar());//toupper : passage en majuscule
    if((colonne < 'A' || colonne > 'O')){
        printf("La Colonne saisie n'est pas compris entre %c et %c !\n",'A','O');
    }
    //Blindage de saisie entre le nombre maximum et le minimum �tabli
    }while(colonne < 'A' || colonne > 'O');

    return colonne;
}

char saisieSensMotPlace(){

    char sens;
    int ok = 0;

    do{
    printf("|Sens Vertical ou Horizontal ? (V ou H) : ");
    //Blindage de saisie a des lettres uniquement
    sens = toupper(saisieChar()); //toupper : passage en majuscule
    //printf("sens= %c ", sens);
    if((sens == 'V' || sens == 'H')){
        ok = 1;
    }
    else{
        printf("Le sens saisi n'est pas %c ou %c !\n",'V','H');
    }
    //Blindage de saisie entre le nombre maximum et le minimum �tabli
    }while(ok == 0);

    return sens;
}

char saisieEntree()
{
       char entree;
       int ok = 0;

    do
    {
        printf("Appuyer sur entree : \n");
        fflush(stdin);
        scanf("%c", &entree);
        if (entree == '\n')
                ok = 1;
    }    while(ok == 0);

    return entree;
}

void saisieMotPlace(MotPlace *motPlace)
{
    printf("Mot a placer : ");
    fflush(stdin);
    scanf("%s",motPlace->mot);
    printf("|Position a saisir : \n");
    //Saisie de la ligne pour placer le mot
    motPlace->ligne = saisieLigneMotPlace();
    //Saisie de la colonne pour placer le mot
    motPlace->colonne = saisieColonneMotPlace();
    //Saisie du sens pour placer le mot
    motPlace->sens = saisieSensMotPlace();
}




