#ifndef SCRABBLE_H
#define SCRABBLE_H

//Librairies
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>


//Variables
#define TAILLE_PLATEAU 16  //Taille des lignes et des colonnes du plateau + titre
#define NUM_LETTRE 102     //Nombre de lettres total du jeu
#define MAX_MOT 51         //51 mots de 2 lettres = 102 lettres
#define TAILLE_CHEVALET 7  //Taille du chevalet de lettre de chaque joueur
#define MIN_JOUEUR 2       //Nombre minimum de joueur par partie
#define MAX_JOUEUR 4       //Nombre maximum de joueur par partie
#define TAILLE_PSEUDO 50   //Nombre maximal de caractère du pseudo d'un joueur
#define CTRL_OK 1          //Controle du mot OK
#define CTRL_KO 0          //Controle du mot KO
#define DERNIERE_PIOCHE 100 //la pioche est presque vide
#define PIOCHE_VIDE      101 //la pioche est vide


//Structures
typedef struct{
    char caractere;
    int valeur;
}Lettre;//Structure representant une lettre du jeu du plateau

typedef struct{
    char legende;
    char caractere;
}Case;//Structure representant une case du plateau

typedef struct{
    char mot[TAILLE_CHEVALET];
    int ligne;
    char colonne;
    char sens;
    int score;
}MotPlace; //Structure pour la gestion du mot a placer

typedef struct{
    int nombreJoueur;
    int tourJoueur;
    int premier_mot;
    Lettre pioche[NUM_LETTRE];
    int lettrePioche;
    MotPlace motplace;
    Case plateau[TAILLE_PLATEAU][TAILLE_PLATEAU];
}Partie; //Structure pour la gestion de la partie


typedef struct{
    int numeroJoueur;
    int masque;
    char pseudo[TAILLE_PSEUDO];
    Lettre chevalet[TAILLE_CHEVALET];
    int score;
}Joueur; //Structure d'un joueur scrabble



//Sous programmes
void clearBuffer(); //Programme qui permet d'effacer le buffer de saisie
int saisieInt(); //Programme qui blinde la saisie d'un entier
void scrabbleJeu(); //Programme du jeu principal


#endif // SCRABBLE_H
