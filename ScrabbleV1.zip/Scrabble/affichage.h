#ifndef AFFICHAGE_H_INCLUDED
#define AFFICHAGE_H_INCLUDED

//Librairies
#include "Scrabble.h"

void afficherJoueur (Joueur joueur);
void creationPlateau(Case plateau[TAILLE_PLATEAU][TAILLE_PLATEAU]);
void afficherPioche(Lettre pioche[]);
void afficherPartieInfo(Joueur joueur);
void afficherPartieInter(MotPlace motPlace);

#endif // AFFICHAGE_H_INCLUDED
