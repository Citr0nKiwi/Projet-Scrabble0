#include "menu.h"

void menuAction(){
    printf("----------------ACTION--------------\n");
    printf("|1) Placer un mot                  |\n");
    printf("|2) Changer une ou plusieurs lettre|\n");
    printf("|3) Passer son tour                |\n");
    printf("|4) Retourner au menu principal    |\n");
    printf("------------------------------------\n");
}

//Programme qui affiche en console le menu
void menuPrincipal(){
    printf("----------------MENU----------------\n");
    printf("|1) Lancer une nouvelle partie     |\n");
    printf("|2) Afficher l'aide                |\n");
    printf("|3) Afficher les scores des joueurs|\n");
    printf("|4) Quitter le jeu                 |\n");
    printf("------------------------------------\n");
}

//Programme qui permet la gestion du menu et des choix utilisateur
void menu(int *scrabble){
    //Variable de choix et de blindage de saisie

    //Affichage utilisateur information choix
    menuPrincipal();

    //Blindage de la saisie du choix
    int choix = saisieInt();

    //Gestion du choix
    switch (choix)
    {
    //Lancer une nouvelle partie
    case 1 :
        //system("cls");
        scrabbleJeu();
        break;
    //Afficher l�aide
    case 2 :
        //system("cls");
        printf("Le Scrabble classique est un jeu de lettres qui se pratique a deux, trois ou quatre joueurs. Les parties opposant deux joueurs, assis l un "
        "face de l autre, sont les seules pratiquees en competition, \nc'est pourquoi le present reglement ne traite que de celles-ci, mais les "
        "regles suivantes sont facilement applicables aux parties a trois ou quatre joueurs. \n");

         printf("Le jeu consiste a former des mots entrecroises sur une grille avec des lettres de valeurs differentes, les cases de couleur de la grille "
            "permettant de multiplier la valeur des lettres ou des mots.\nLe gagnant est celui qui cumule le plus grand nombre de points a l issue de "
            "la partie. \n");
        break;
    //Afficher les scores des joueurs
    case 3 :
        //system("cls");
        printf("Score\n");
        break;
    //Quitter le jeu
    case 4 :
        *scrabble = 0;
        //system("cls");
        printf("Merci d'avoir joue !\n");
        break;
    //Gestion des saisies autres que celles pris en charge
    default:
        //system("cls");
        printf("Saisissez un numero entre 1 et 4 uniquement !\n\n");
        break;
    }

}
