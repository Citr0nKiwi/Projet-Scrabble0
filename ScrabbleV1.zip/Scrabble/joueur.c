#include "joueur.h"


//Programme qui cr�e un chevalet pour un joueur en prenant en param�tre le numero du joueur cr�e
int creationChevalet(int numeroJoueur,Joueur *joueur,Partie *partie){
    int i;

    //printf("index lettre piochee : %d \n",partie->lettrePioche);
    //Generation du chevalet
    if (partie->lettrePioche < NUM_LETTRE - TAILLE_CHEVALET){
        for(i = 0; i < TAILLE_CHEVALET; i++)
            {
            joueur->chevalet[i] = partie->pioche[partie->lettrePioche];
            partie->lettrePioche++;
            // printf("%c%d ", joueur->chevalet[i].caractere, joueur->chevalet[i].valeur);
            }
    }
    else {
        printf("Il reste moins de 7 lettres dans la pioche !!! \n");
            return(DERNIERE_PIOCHE);
    }

   // printf("\n");
   return(1);
}


//Programme qui retourne la chaine du chevalet
void chaineChevalet(Joueur *joueur, char chaine[TAILLE_CHEVALET]){
    int i;

     for(i = 0; i < TAILLE_CHEVALET; i++)
        {
        chaine[i] = joueur->chevalet[i].caractere;
        }

   printf("\n");
}

//Programme qui cr�e un joueur en prenant en param�tre le numero du joueur cr�e
void creationJoueur(int numeroJoueur,Joueur *joueur,Partie *partie){

    int i;

    printf("Saisissez votre pseudo Joueur%d (MAX : %d CARACTERES):\n",numeroJoueur,TAILLE_PSEUDO);

    fflush(stdin);
    scanf("%s",&(joueur->pseudo));
    joueur->masque = 0;
    joueur->score = 0;
    joueur->numeroJoueur = numeroJoueur;

    //Generation du chevalet
    creationChevalet(numeroJoueur, joueur, partie);
}


int choixNombreJoueur(){

    int nombreJoueur;
    do{
    printf("Choisir le nombre de joueur compris entre %d et %d :\n",MIN_JOUEUR,MAX_JOUEUR);
    //Blindage de saisie a des chiffres uniquements
    nombreJoueur = saisieInt();
    if((nombreJoueur < MIN_JOUEUR || nombreJoueur > MAX_JOUEUR)){
        printf("Le nombre saisie n'est pas compris entre %d et %d !\n",MIN_JOUEUR,MAX_JOUEUR);
    }
    //Blindage de saisie entre le nombre maximum et le minimum �tabli
    }while(nombreJoueur < MIN_JOUEUR || nombreJoueur > MAX_JOUEUR);

    return nombreJoueur;
}

//Tirage al�atoire du premier joueur
int tiragePremierJoueur(Partie *partie){

    int premierJoueur;

    //tirage al�atoire
    premierJoueur = rand()%(partie->nombreJoueur);

    return(premierJoueur);
}
