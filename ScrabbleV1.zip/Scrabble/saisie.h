#ifndef SAISIE_H_INCLUDED
#define SAISIE_H_INCLUDED

//Librairies
#include "Scrabble.h"

//Sous programmes
void clsBuffer();
int saisieInt();
void saisieMot(char mot);
void saisieMotPlace(MotPlace *motPlace);

#endif // SAISIE_H_INCLUDED
