//Librairies

#include "Scrabble.h"
#include "pioche.h"
#include "joueur.h"
#include "affichage.h"
#include "saisie.h"


void scrabbleJeu(){

    int jouer = 1;
    int i;
    int tourJoueur = 1;
    int controle = CTRL_KO;
    int resultat = 0;
    int contact = 0;
    char chChevalet[TAILLE_CHEVALET]={' '};
    char lettresAplacer[TAILLE_CHEVALET]={' '};
    int nbLettresAplacer = 0;

  //Partie partie;
    Partie* partie = (Partie*)malloc(sizeof(Partie));

    creationPioche(partie->pioche);
    partie->lettrePioche = 0;
    creationPlateau(partie->plateau);
    partie->nombreJoueur = choixNombreJoueur();
    partie->premier_mot = 1;
    partie->motplace.colonne = ' ';
    partie->motplace.ligne = 0;
    strcpy(partie->motplace.mot, " ");
    partie->motplace.sens = ' ';

    Joueur* listeJoueur = (Joueur*)malloc(partie->nombreJoueur * sizeof(Joueur));


    for(i = 0; i < partie->nombreJoueur;i++){
        creationJoueur((i + 1),&(listeJoueur[i]), partie);
    }


//    for(i = 0; i < partie->nombreJoueur; i++){
//        afficherJoueur(listeJoueur[i]);
//    }
    system("cls");

    //tirage aleatoire du premier joueur
    printf("********* Tirage 1er joueur :*********\n");
    partie->tourJoueur = tiragePremierJoueur(partie);
    printf("Le joueur %d commence.\n", partie->tourJoueur+1);

    while(jouer){

        //affichage du plateau
        afficherPlateau(partie->plateau);

        //Affichage de la partie information du joueur 1
        afficherPartieInfo(listeJoueur[partie->tourJoueur]);

        //Affichage de la partie interaction du joueur
        afficherPartieInter(partie->motplace);

        //Affichage des actions possibles
        menuAction();

        //Demande de saisie du choix
        int choix = saisieInt();

        //Demande d'action du joueur
        switch (choix)
        {
        case 1 :
            //saisie du mot a placer
            saisieMotPlace(&(partie->motplace));
            //recuperation du chevalet du joueur
            chaineChevalet(&(listeJoueur[partie->tourJoueur]), chChevalet);
            //Controle du placement du mot, recuperation des lettres a placer en fonction des lettres existantes sur le plateau
            controle = controlePlacementMot(partie->plateau, partie->motplace, lettresAplacer, &nbLettresAplacer);
            //printf("controle %d", controle);
            if (controle != CTRL_OK){
                printf("Le mot ne peut pas etre place a cet emplacement, recommencez !!! \n");
            }else{
                //Controle si les lettres a placer peuvent etre prises dans le chevalet
                //printf("***** lettresAplacer %s", lettresAplacer);
                controle = controleMotValide(lettresAplacer, chChevalet, &nbLettresAplacer);
                //printf("controle %d", controle);
                if (controle != CTRL_OK){
                    printf("Le mot propose ne peut pas etre ecrit avec les lettres du chevalet, recommencez !!! \n");
                }
                else{
                //Controle du placement du mot
                //controle = controlePlacementMot(partie->plateau, partie->motplace, lettresAplacer);
                //printf("controle = %d \n", controle);
                if (controle == CTRL_OK){
                    //placer le mot sur le plateau
                    if (partie->premier_mot == 1) //Si premier mot, doit �tre sur #
                    {
                        resultat = placePremierMot(partie->plateau, partie->motplace);
                        if(resultat == 1 ){//si le mot est bien plac� sur #, on le place sinon on doit recomencer
                            //ce n'est plus le premier mot
                            partie->premier_mot = 0;
                            //calcul du score du mot
                            partie->motplace.score = calculeScoreMot(partie->plateau, partie->motplace);
                            //mise a jour du score du joueur
                            listeJoueur[partie->tourJoueur].score = listeJoueur[partie->tourJoueur].score + partie->motplace.score;
                            printf("Le score de %s passe a %d points !!! \n", listeJoueur[partie->tourJoueur].pseudo, listeJoueur[partie->tourJoueur].score);
                            //creation nouveau chevalet
                            creationChevalet(partie->tourJoueur,&(listeJoueur[partie->tourJoueur]),partie);
                            //passage au joueur suivant
                            partie->tourJoueur = partie->tourJoueur + 1;
                                if (partie->tourJoueur == partie->nombreJoueur)
                                    partie->tourJoueur = 0;
                        }
                        else //le mot n'est pas plac� sur #
                        {  //on est toujours sur le premier mot
                            partie->premier_mot = 1;
                        }
                    }
                    else {//test si contact avec mot existant
                        contact = contactMotExistant(partie->plateau, partie->motplace);
                        if(contact == 1) {
                            placeMot(partie->plateau, partie->motplace);
                            //calcul du score du mot
                            partie->motplace.score = calculeScoreMot(partie->plateau, partie->motplace);
                            //mise a jour du score du joueur
                            listeJoueur[partie->tourJoueur].score = listeJoueur[partie->tourJoueur].score + partie->motplace.score;
                            printf("Le score de %s passe a %d points !!! \n", listeJoueur[partie->tourJoueur].pseudo, listeJoueur[partie->tourJoueur].score);
                            //creation nouveau chevalet
                            creationChevalet(partie->tourJoueur,&(listeJoueur[partie->tourJoueur]),partie);
                            //passage au joueur suivant
                            partie->tourJoueur = partie->tourJoueur + 1;
                            if (partie->tourJoueur == partie->nombreJoueur)
                                partie->tourJoueur = 0;
                            //remise � zero de contact pour prochain mot
                            contact = 0;
                            }
                        else{
                            printf("Pas de contact avec mot existant, recommencez !!! \n");
                            //remise � zero de contact pour prochain mot
                            contact = 0;
                            }
                        }
                    }
                }
            }
            //saisir entree le temps de lire les messages
            saisieEntree();
            //effacement ecran
            system("cls");
            break;
        case 2 :
            //Changement des lettres du chevalet
            system("cls");
            printf("Changement des lettres du chevalet\n");
            creationChevalet(partie->tourJoueur,&(listeJoueur[partie->tourJoueur]),partie);
            //passage au joueur suivant
            partie->tourJoueur = partie->tourJoueur + 1;
            if (partie->tourJoueur == partie->nombreJoueur)
                partie->tourJoueur = 0;
            printf("C'est au tour du joueur %d. \n", (partie->tourJoueur)+1);
            break;
        case 3 :
            //Passer son tour
            printf("Passer son tour (O/N):\n");
            scanf("%c", &choix);
            if (choix == 'O' || choix == 'o'){
                printf("Le joueur %d passe son tour. \n", (partie->tourJoueur)+1);
                //passage au joueur suivant
                partie->tourJoueur = partie->tourJoueur + 1;
                if (partie->tourJoueur == partie->nombreJoueur)
                    partie->tourJoueur = 0;
                printf("C'est au tour du joueur %d. \n", (partie->tourJoueur)+1);
            } else if (choix == 'N' || choix == 'n'){
                printf("Le joueur %d joue normalement. \n", (partie->tourJoueur)+1);
            } else if(choix != 'O' ||choix != 'o' ||choix != 'N' ||choix != 'n'){
                printf("Mauvaise saisie. \n");
            }
            break;
        case 4 :
            //Stopper la partie
            system("cls");
            printf("Partie stoppee !\n");
            partie->lettrePioche = 0;
            jouer = 0;
            partie->premier_mot = 1;
            break;

        default:
            system("cls");
            printf("Choix non valide !");
            break;
        }
    }

    free(partie);
    free(listeJoueur);

}













