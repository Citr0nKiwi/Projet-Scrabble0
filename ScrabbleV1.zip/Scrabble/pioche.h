#ifndef PIOCHE_H_INCLUDED
#define PIOCHE_H_INCLUDED

//Sous programmes
void creationPioche(Lettre pioche[NUM_LETTRE]);
void Melange_Fisher_Yates(Lettre pioche[]);

#endif // PIOCHE_H_INCLUDED
