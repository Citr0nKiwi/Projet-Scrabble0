#ifndef JOUEUR_H_INCLUDED
#define JOUEUR_H_INCLUDED

//Librairies
#include "Scrabble.h"
#include "plateau.h"


//Sous programmes
int creationChevalet(int numeroJoueur,Joueur *joueur,Partie *partie);
void chaineChevalet(Joueur *joueur, char chaine[TAILLE_CHEVALET]);
void creationJoueur(int numeroJoueur,Joueur *joueur,Partie *partie);
int choixNombreJoueur();
int tiragePremierJoueur(Partie *partie);


#endif // JOUEUR_H_INCLUDED
