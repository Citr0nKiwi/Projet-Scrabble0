#ifndef CONTROLE_H_INCLUDED
#define CONTROLE_H_INCLUDED
#include "Scrabble.h"

int controleMotValide(char mot[TAILLE_CHEVALET], char chevalet[TAILLE_CHEVALET],int *nblettresAplacer);
int controlePlacementMot(Case plateau[TAILLE_PLATEAU][TAILLE_PLATEAU], MotPlace motPlace, char lettresAplacer[TAILLE_CHEVALET],int *nblettresAplacer);

#endif // CONTROLE_H_INCLUDED
