#ifndef PLATEAU_H_INCLUDED
#define PLATEAU_H_INCLUDED

//Librairies
#include "Scrabble.h"


//Sous programmes
void creationPlateau(Case plateau[TAILLE_PLATEAU][TAILLE_PLATEAU]);
void placeMot(Case plateau[TAILLE_PLATEAU][TAILLE_PLATEAU], MotPlace motPlace);
int contactMotExistant(Case plateau[TAILLE_PLATEAU][TAILLE_PLATEAU], MotPlace motPlace);
#endif // PLATEAU_H_INCLUDED
