#include "Scrabble.h"


//Programme principal
int main(void)
{
   //srand(time(NULL));
   // system("cls");
    int scrabble = 1;

    while(scrabble){
        menu(&scrabble);
    }

    return 0;
}
