#include "calculScore.h"

//fonction qui retourne la valeur a multiplier en fonction de la legende d'une case
int multipleLettre(char laCase){
    switch (laCase){
            case '&':
                return 2;
            case '%':
                return 3;
            default:
                return 1;  // Valeur par d�faut
    }
}

//fonction qui retourne si le mot est compte double ou compte triple
int multipleMot(char laCase){
    switch (laCase){
            case '#':
            case '@':
                return 2;
            case '�':
                printf("�");
                return 3;
            default:
                return 1;  // Valeur par d�faut
    }
}


//fonction qui retourne la valeur d'une lettre
int valeurLettre(char lettre){
    switch (toupper(lettre)){
            case 'A':
            case 'E':
            case 'I':
            case 'L':
            case 'N':
            case 'O':
            case 'R':
            case 'S':
            case 'T':
            case 'U':
                return 1;
            case 'D':
            case 'G':
            case 'M':
                return 2;
            case 'B':
            case 'C':
            case 'P':
                return 3;
            case 'F':
            case 'H':
            case 'V':
                return 4;
            case 'J':
            case 'Q':
                return 8;
            case 'K':
            case 'W':
            case 'X':
            case 'Y':
            case 'Z':
                return 10;
            default:
                return 0;  // Valeur par d�faut pour les caract�res non pris en charge
    }
}


//Fonction qui calcule le score d'un mot
int calculeScoreMot(Case plateau[TAILLE_PLATEAU][TAILLE_PLATEAU], MotPlace motPlace){
int i,j,k;
Case laCase;
int vLettre = 0;
int mLettre = 0;
int mMot = 0;
int motDouble = 0;
int motTriple = 0;

motPlace.score = 0;

i = (motPlace.ligne);
j = (int)(motPlace.colonne)-64;

for(k = 0; k < strlen(motPlace.mot);k++){//Parcours du mot place
          vLettre = valeurLettre(motPlace.mot[k]); //retourne la valeur de la lettre

          mLettre = multipleLettre(plateau[i][j].legende); //retourne si la case est une lettre compte double ou compte triple

          motPlace.score = motPlace.score + vLettre*mLettre; //calcul du score du mot

          mMot = multipleMot(plateau[i][j].legende);

          if (mMot == 2) //test si le mot est sur une case mo compte double
            motDouble = 1;
          if (mMot == 3) //test si le mot est sur une case mo compte triple
            motTriple = 1;

          if(motPlace.sens == 'H')
                    j++;
          if(motPlace.sens == 'V')
                    i++;
}

if (motTriple == 1) //si mot compte tripe on triple le score
    motPlace.score  = motPlace.score * 3;
else if (motDouble == 1) //si mot compte double on double le score
    motPlace.score  = motPlace.score * 2;


printf("Le score du mot est egal a %d points. \n", motPlace.score);

return(motPlace.score);
}
