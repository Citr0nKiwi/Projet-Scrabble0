#include "controle.h"

// Fonction pour v�rifier si un mot peut �tre form� � partir des lettres du chevalet
int controleMotValide(char mot[TAILLE_CHEVALET], char chevalet[TAILLE_CHEVALET], int *nbLettresAplacer)
{
    int i;
    int nbLettreChevalet[26] = {0}; // Nb de A, de B, de C...dans le chevalet
    int nbLettreMot[26] = {0};      // Nb de A, de B, de C dans le mot propose

 //   printf("2*** mot %s", mot);
 //   printf("2*** chevalet %s", chevalet);


    // Remplir le nombre de A, de B, de C dans le chevalet
    for(i = 0; i < TAILLE_CHEVALET;i++){//Parcours du chevalet
        nbLettreChevalet[toupper(chevalet[i]) - 'A']++;
    }

    // Remplir le nombre de A, de B, de C dans le mot
  //  for(i = 0; i < strlen(mot);i++){//Parcours du mot propose
    for(i = 0; i < *nbLettresAplacer;i++){//Parcours du mot propose
        nbLettreMot[toupper(mot[i]) - 'A']++;
    }

    // V�rifier si chaque lettre dans le mot a une occurrence inf�rieure ou �gale � celle dans le chevalet
    for (int i = 0; i < 26; i++) {
        if (nbLettreMot[i] > nbLettreChevalet[i]) {
            return(0); // Le mot ne peut pas �tre form�
        }
    }

    return(1); // Le mot peut �tre form�
}

// Fonction pour v�rifier si le mot peut �tre plac� sur le plateau
int controlePlacementMot(Case plateau[TAILLE_PLATEAU][TAILLE_PLATEAU], MotPlace motPlace, char lettresAplacer[TAILLE_CHEVALET], int *nbLettresAplacer)
{
    int i,j,k,l;

    l = 0;

    i = (motPlace.ligne);
    j = (int)(motPlace.colonne)-64;

    // printf("Controle du mot: ");

    //Controle Ligne hors-plateau
    if(motPlace.sens == 'H'){
        if((motPlace.colonne -64 + strlen(motPlace.mot)) > 'O'){
           // printf("motPlace.colonne %d \n", motPlace.colonne);
           // printf("strlen(motPlace.mot) %d \n", strlen(motPlace.mot));
           // printf("motPlace.colonne + strlen(motPlace.mot) %d \n", motPlace.colonne + strlen(motPlace.mot));
            printf("La place choisie est hors-plateau \n");
            return(0);
        }
    }else if(motPlace.sens == 'V'){
        if((motPlace.ligne + strlen(motPlace.mot)) > TAILLE_PLATEAU){
          //  printf("motPlace.ligne %d \n", motPlace.ligne );
         //   printf("strlen(motPlace.mot) %d \n", strlen(motPlace.mot));
          //  printf("motPlace.ligne + strlen(motPlace.mot) %d \n", motPlace.ligne + strlen(motPlace.mot));
            printf("La place choisie est hors-plateau \n");
            return(0);
        }
    }

    //Controle plateau pas d'�crasement de lettre
    for(k = 0; k < strlen(motPlace.mot);k++){//Parcours du mot place
        if(plateau[i][j].caractere != ' '){//si la case n'est pas vide => test si lettre differente
              //  printf("plateau[i][j].caractere %c \n", plateau[i][j].caractere);
                if (motPlace.mot[k] != plateau[i][j].caractere){
                    printf("Ecrasement de lettre !!!\n");
                    return(0);
                }
        }
        else
        {//la lettre n'est pas sur le plateau => lettre est a placer sur le plateau
            lettresAplacer[l] = motPlace.mot[k];
          //  printf("l : %d \n", l);
         //   printf("motPlace.mot[k] %c \n", motPlace.mot[k]);
         //   printf("lettresAplacer[l] %c \n", lettresAplacer[l]);
            l++;
        }
        if(motPlace.sens == 'H')
            j++;
        if(motPlace.sens == 'V')
            i++;
    }

    if (l < TAILLE_CHEVALET) //si moins de 7 lettres a ecrire, on remplit la chaine avec des espaces
    {
        for(k = l; k < TAILLE_CHEVALET; k++)
        {
         //   printf("1*** l %d \n", l);
         //   printf("1*** lettresAplacer[k] %c \n", lettresAplacer[k]);
            lettresAplacer[k]=' ';
        //    printf("1*** lettresAplacer %s \n", lettresAplacer);
        }
    *nbLettresAplacer = l;
    }


    return(1);
}
