#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

//Sous programmes
void menu(int *scrabble); //Gestion du menu et des choix
void menuPrincipal(); //menu principal
void menuAction(); //menu action

#endif // MENU_H_INCLUDED
