#ifndef CALCULSCORE_H_INCLUDED
#define CALCULSCORE_H_INCLUDED

//Librairies
#include "Scrabble.h"


int multipleLettre(char laCase);
int multipleMot(char laCase);
int valeurLettre(char lettre);
#endif // CALCULSCORE_H_INCLUDED
