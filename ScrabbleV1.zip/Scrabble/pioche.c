
#include "Scrabble.h"

void creationPioche(Lettre pioche[NUM_LETTRE]){
    int i = 0;

    for(i = 0; i < 9; i++){
        pioche[i].caractere = 'A';
        pioche[i].valeur = 1;
    }


    for(i = 9; i < 11; i++){
        pioche[i].caractere = 'B';
        pioche[i].valeur = 3;
    }


    for (i = 11; i < 13; i ++){
        pioche[i].caractere = 'C';
        pioche[i].valeur = 3;
    }


    for (i = 13; i < 16; i ++){
        pioche[i].caractere = 'D';
        pioche[i].valeur = 2;
    }

    for (i = 16; i < 31; i ++){
        pioche[i].caractere = 'E';
        pioche[i].valeur = 1;
    }

    for (i = 31; i < 33; i ++){
        pioche[i].caractere = 'F';
        pioche[i].valeur = 4;
    }


    for (i = 33; i < 35; i ++){
        pioche[i].caractere = 'G';
        pioche[i].valeur = 2;
    }


    for (i = 35; i < 37; i ++){
        pioche[i].caractere = 'H';
        pioche[i].valeur = 4;
    }


    for (i = 37; i < 45; i ++){
        pioche[i].caractere = 'I';
        pioche[i].valeur = 1;
    }


    pioche[45].caractere = 'J';
    pioche[45].valeur = 8;


    pioche[46].caractere = 'K';
    pioche[46].valeur = 10;

    for (i = 47; i < 52; i ++){
        pioche[i].caractere = 'L';
        pioche[i].valeur = 1;
    }

    for (i = 52; i < 55; i ++){
        pioche[i].caractere = 'M';
        pioche[i].valeur = 2;
    }

    for (i = 55; i < 61; i ++){
        pioche[i].caractere = 'N';
        pioche[i].valeur = 1;
    }

    for (i = 61; i < 67; i ++){
        pioche[i].caractere = 'O';
        pioche[i].valeur = 1;
    }

    for (i = 67; i < 69; i ++){
        pioche[i].caractere = 'P';
        pioche[i].valeur = 3;
    }

    pioche[69].caractere = 'Q';
    pioche[69].valeur = 8;

    for (i = 70; i < 76; i ++){
        pioche[i].caractere = 'R';
        pioche[i].valeur = 1;
    }

    for (i = 76; i < 82; i ++){
        pioche[i].caractere = 'S';
        pioche[i].valeur = 1;
    }

    for (i = 82; i < 88; i ++){
        pioche[i].caractere = 'T';
        pioche[i].valeur = 1;
    }

    for (i = 88; i < 94; i ++){
        pioche[i].caractere = 'U';
        pioche[i].valeur = 1;
    }

    for (i = 94; i < 96; i ++){
        pioche[i].caractere = 'V';
        pioche[i].valeur = 4;
    }

    pioche[96].caractere = 'W';
    pioche[96].valeur = 10;

    pioche[97].caractere = 'X';
    pioche[97].valeur = 10;
    pioche[98].caractere = 'Y';
    pioche[98].valeur = 10;
    pioche[99].caractere = 'Z';
    pioche[99].valeur = 10;

    for (i = 100; i < 102; i ++){
        pioche[i].caractere = '?';
        pioche[i].valeur = 0;
    }

    //m�langer la pioche avec m�thode Fisher Yates;
    Melange_Fisher_Yates(pioche);

    //DEBUG affichage pioche
    //afficherPioche(pioche);
}

//Pour m�langer un tableau de charactere : m�thode Fisher Yates
void Melange_Fisher_Yates(Lettre pioche[]){
    int i,j;
    for(i = NUM_LETTRE - 1; i > 0; i--)
    {
        j = rand()%(i+1);

        Lettre temp = pioche[i];
        pioche[i] = pioche[j];
        pioche[j] = temp;
    }
}
